
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from './services/supabaseClient';
import { FinancialMentorService } from './services/geminiService';
import { Role, Message, Bill, User, Expense, Profile } from './types';
import { 
  SendIcon, WalletIcon, GraphIcon, MotoIcon, BotIcon, 
  AlertIcon, TrashIcon, CalendarIcon, ChevronDownIcon,
  ChevronLeftIcon, ChevronRightIcon,
  LogoutIcon, UserIcon, LockIcon, SupportIcon, BellIcon,
  AppLogo
} from './components/Icons';
import MarkdownRenderer from './components/MarkdownRenderer';

const MONTHS = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
const DAYS_OF_WEEK = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];

const App: React.FC = () => {
  const [session, setSession] = useState<any>(null);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [activeTab, setActiveTab] = useState<'chat' | 'ledger' | 'stats' | 'calendar' | 'help'>('chat');
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );
  const [notifsEnabled, setNotifsEnabled] = useState(() => {
    return localStorage.getItem('moto_notifs_muted') !== 'true';
  });

  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardingData, setOnboardingData] = useState<Profile>({
    age: '', gender: '', experience: '', tool: '', days_week: '', hours_day: '',
    platforms: [], accident: false, challenge: '',
    moto_oil_price: 45, moto_fuel_price: 5.80, moto_km_per_liter: 35,
    financial_goal: 5000, goal_name: 'Reserva de Emergência'
  });

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [globalError, setGlobalError] = useState<string | null>(null);

  const [messages, setMessages] = useState<Message[]>([]);
  const [dailyEarnings, setDailyEarnings] = useState<any[]>([]);
  const [dailyExpenses, setDailyExpenses] = useState<Expense[]>([]);
  const [bills, setBills] = useState<Bill[]>([]);
  const [userProfile, setUserProfile] = useState<Profile | null>(null);
  const [viewDate, setViewDate] = useState(new Date());
  
  const [inputText, setInputText] = useState('');
  const [tempEarning, setTempEarning] = useState('');
  const [tempExpense, setTempExpense] = useState('');
  const [isAILoading, setIsAILoading] = useState(false);
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [isDatePickerOpen, setIsDatePickerOpen] = useState(false);

  const mentorService = useRef<FinancialMentorService | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, []);

  useEffect(() => {
    if (activeTab === 'chat') {
      setTimeout(scrollToBottom, 150);
    }
  }, [messages, activeTab, scrollToBottom]);

  const totals = useMemo(() => {
    const month = viewDate.getMonth();
    const year = viewDate.getFullYear();
    const earnings = dailyEarnings.filter(e => {
      const d = new Date(e.date);
      return d.getUTCMonth() === month && d.getUTCFullYear() === year;
    });
    const expenses = dailyExpenses.filter(e => {
      const d = new Date(e.date);
      return d.getUTCMonth() === month && d.getUTCFullYear() === year;
    });
    const currentBills = bills.filter(b => {
      const [bYear, bMonth] = b.dueDate.split('-').map(Number);
      return bMonth === (month + 1) && bYear === year;
    }).sort((a, b) => a.dueDate.localeCompare(b.dueDate));

    const totalEarned = earnings.reduce((acc, curr) => acc + Number(curr.value), 0);
    const totalSpent = expenses.reduce((acc, curr) => acc + Number(curr.value), 0);

    return { totalEarned, totalSpent, netProfit: totalEarned - totalSpent, currentBills };
  }, [dailyEarnings, dailyExpenses, bills, viewDate]);

  const billsByWeek = useMemo(() => {
    const weeks: Record<number, Bill[]> = { 1: [], 2: [], 3: [], 4: [], 5: [] };
    totals.currentBills.forEach(bill => {
      const day = parseInt(bill.dueDate.split('-')[2]);
      const weekNum = Math.ceil(day / 7);
      weeks[Math.min(weekNum, 5)].push(bill);
    });
    return weeks;
  }, [totals.currentBills]);

  const calendarDays = useMemo(() => {
    const year = viewDate.getFullYear();
    const month = viewDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    return { firstDay, daysInMonth };
  }, [viewDate]);

  const checkUpcomingBills = useCallback((billsList: Bill[]) => {
    if (!notifsEnabled || notifPermission !== 'granted') return;
    const today = new Date();
    const threeDaysFromNow = new Date();
    threeDaysFromNow.setDate(today.getDate() + 3);

    const upcoming = billsList.filter(bill => {
      if (bill.isPaid) return false;
      const dueDate = new Date(bill.dueDate + 'T00:00:00');
      return dueDate >= today && dueDate <= threeDaysFromNow;
    });

    upcoming.forEach(bill => {
      const notifKey = `notified_${bill.id}_${new Date().toDateString()}`;
      if (!localStorage.getItem(notifKey)) {
        new Notification("MotoInvest: Conta!", {
          body: `Sua conta "${bill.name}" vence em breve.`,
          icon: 'https://cdn-icons-png.flaticon.com/512/3198/3198336.png'
        });
        localStorage.setItem(notifKey, 'true');
      }
    });
  }, [notifsEnabled, notifPermission]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) setCurrentUser({ email: session.user.email!, name: session.user.user_metadata?.name || 'Comandante' });
      setIsInitialLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session?.user) setCurrentUser({ email: session.user.email!, name: session.user.user_metadata?.name || 'Comandante' });
      else { setCurrentUser(null); setMessages([]); }
    });
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!session?.user) return;
    const loadData = async () => {
      const { data: profile } = await supabase.from('profiles').select('*').eq('user_id', session.user.id).single();
      if (!profile) setShowOnboarding(true);
      else setUserProfile(profile);

      const { data: msgs } = await supabase.from('chat_messages').select('*').eq('user_id', session.user.id).order('timestamp', { ascending: true });
      const { data: earns } = await supabase.from('earnings').select('*').eq('user_id', session.user.id).order('date', { ascending: false });
      const { data: exps } = await supabase.from('expenses').select('*').eq('user_id', session.user.id).order('date', { ascending: false });
      const { data: bls } = await supabase.from('bills').select('*').eq('user_id', session.user.id).order('dueDate', { ascending: true });
      
      if (msgs && msgs.length > 0) setMessages(msgs.map(m => ({ role: m.role, text: m.text, timestamp: m.timestamp })));
      else setMessages([{ role: Role.MODEL, text: `Salve, **${currentUser?.name}**! 🏍️\nQuanto rendeu o corre hoje?`, timestamp: new Date().toISOString() }]);
      
      if (earns) setDailyEarnings(earns);
      if (exps) setDailyExpenses(exps);
      if (bls) { setBills(bls); checkUpcomingBills(bls); }
    };
    loadData();
    mentorService.current = new FinancialMentorService();
  }, [session, currentUser, checkUpcomingBills]);

  const navigateMonth = (step: number) => {
    setViewDate(prev => {
      const newDate = new Date(prev);
      newDate.setMonth(prev.getMonth() + step);
      return newDate;
    });
  };

  const handleAuth = async () => {
    setIsAuthLoading(true);
    try {
      if (authMode === 'register') {
        const { error } = await supabase.auth.signUp({ email, password, options: { data: { name } } });
        if (error) throw error;
        setAuthMode('login');
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
      }
    } catch (err: any) { setGlobalError(err.message); }
    finally { setIsAuthLoading(false); }
  };

  const handleOnboardingSubmit = async () => {
    if (!session?.user) return;
    const { error } = await supabase.from('profiles').insert([{ user_id: session.user.id, ...onboardingData }]);
    if (!error) {
      setShowOnboarding(false);
      setUserProfile(onboardingData);
      processAIPrompt("Acabei de criar meu perfil. Me dá umas boas vindas!");
    }
  };

  const updateMotoProfile = async (updates: Partial<Profile>) => {
    if (!session?.user) return;
    const { error } = await supabase.from('profiles').update(updates).eq('user_id', session.user.id);
    if (!error) setUserProfile(prev => prev ? { ...prev, ...updates } : null);
  };

  // Fix: Helper functions for UI interaction
  const getDayStatus = (day: number) => {
    const dateStr = `${viewDate.getFullYear()}-${String(viewDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    const dayBills = bills.filter(b => b.dueDate === dateStr);
    if (dayBills.length === 0) return null;
    return dayBills.every(b => b.isPaid) ? 'paid' : 'due';
  };

  const toggleBillPaid = async (id: string, currentStatus: boolean) => {
    if (!session?.user) return;
    const { error } = await supabase.from('bills').update({ isPaid: !currentStatus }).eq('id', id);
    if (!error) {
      setBills(prev => prev.map(b => b.id === id ? { ...b, isPaid: !currentStatus } : b));
    }
  };

  const deleteBill = async (id: string) => {
    if (!session?.user) return;
    const { error } = await supabase.from('bills').delete().eq('id', id);
    if (!error) {
      setBills(prev => prev.filter(b => b.id !== id));
    }
  };

  const toggleNotifs = () => {
    setNotifsEnabled(prev => {
      const newVal = !prev;
      localStorage.setItem('moto_notifs_muted', String(!newVal));
      return newVal;
    });
  };

  const requestNotifPermission = async () => {
    if (typeof Notification === 'undefined') return;
    const permission = await Notification.requestPermission();
    setNotifPermission(permission);
    if (permission === 'granted') {
      setNotifsEnabled(true);
      localStorage.setItem('moto_notifs_muted', 'false');
    }
  };

  const processAIPrompt = async (prompt: string) => {
    if (!mentorService.current || isAILoading || !prompt.trim()) return;
    const userMsg = { role: Role.USER, text: prompt, timestamp: new Date().toISOString() };
    setMessages(prev => [...prev, userMsg]);
    setIsAILoading(true);
    if (session?.user) await supabase.from('chat_messages').insert([{ user_id: session.user.id, ...userMsg }]);
    try {
      const response = await mentorService.current.sendMessage(prompt);
      
      // Fix: Handle tool/function calls from Gemini response to integrate with Supabase
      if (response.functionCalls && response.functionCalls.length > 0) {
        for (const fc of response.functionCalls) {
          if (fc.name === 'add_bill' && session?.user) {
            const { name, amount, dueDate } = fc.args;
            const { data, error } = await supabase.from('bills').insert([{
              user_id: session.user.id,
              name,
              amount,
              dueDate,
              isPaid: false
            }]).select();
            if (data && !error) {
              setBills(prev => [...prev, data[0]]);
            }
          }
        }
      }

      const modelMsg = { role: Role.MODEL, text: response.text, timestamp: new Date().toISOString() };
      setMessages(prev => [...prev, modelMsg]);
      if (session?.user) await supabase.from('chat_messages').insert([{ user_id: session.user.id, ...modelMsg }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: Role.MODEL, text: "Ops, falhei na conexão.", timestamp: new Date().toISOString() }]);
    } finally { setIsAILoading(false); }
  };

  const handleSaveDay = async () => {
    const earnVal = parseFloat(tempEarning) || 0;
    const expVal = parseFloat(tempExpense) || 0;
    if ((!earnVal && !expVal) || !session?.user) return;
    const dateStr = new Date().toLocaleDateString('en-CA');
    if (earnVal) {
      const { data } = await supabase.from('earnings').insert([{ user_id: session.user.id, value: earnVal, date: dateStr }]).select();
      if (data) setDailyEarnings(p => [data[0], ...p]);
    }
    if (expVal) {
      const { data } = await supabase.from('expenses').insert([{ user_id: session.user.id, value: expVal, date: dateStr }]).select();
      if (data) setDailyExpenses(p => [data[0], ...p]);
    }
    setTempEarning(''); setTempExpense(''); setActiveTab('chat');
    processAIPrompt(`Fiz R$ ${earnVal} brutos e gastei R$ ${expVal}. Me ajuda a dividir esse lucro?`);
  };

  if (isInitialLoading) return <div className="h-screen bg-[#020617] flex items-center justify-center animate-pulse text-emerald-500 font-black">MOTOINVEST...</div>;

  if (!currentUser) {
    return (
      <div className="flex flex-col h-screen items-center justify-center p-6 bg-animate text-white">
        <div className="w-full max-w-sm space-y-8 animate-in fade-in zoom-in">
          <div className="text-center">
            <AppLogo className="w-24 h-24 mx-auto relative mb-4" />
            <h1 className="text-4xl font-black italic tracking-tighter uppercase">MotoInvest</h1>
            <p className="text-emerald-400 font-bold text-[10px] tracking-widest uppercase">Mentor do Motoca</p>
          </div>
          <div className="bg-slate-900/50 backdrop-blur-xl border border-white/5 p-8 rounded-[40px] space-y-4">
            <div className="flex bg-white/5 p-1 rounded-2xl">
              <button onClick={() => setAuthMode('login')} className={`flex-1 py-3 rounded-xl text-xs font-black uppercase ${authMode === 'login' ? 'bg-emerald-600' : 'text-slate-500'}`}>Entrar</button>
              <button onClick={() => setAuthMode('register')} className={`flex-1 py-3 rounded-xl text-xs font-black uppercase ${authMode === 'register' ? 'bg-emerald-600' : 'text-slate-500'}`}>Criar</button>
            </div>
            {authMode === 'register' && <input type="text" placeholder="Nome Completo" value={name} onChange={e => setName(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-4 text-sm" />}
            <input type="email" placeholder="Seu melhor email" value={email} onChange={e => setEmail(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-4 text-sm" />
            <input type="password" placeholder="Senha" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-4 text-sm" />
            {globalError && <p className="text-rose-500 text-[10px] font-bold text-center">{globalError}</p>}
            <button onClick={handleAuth} className="w-full bg-emerald-600 py-4 rounded-2xl font-black uppercase shadow-xl active-scale">COMEÇAR O CORRE</button>
          </div>
        </div>
      </div>
    );
  }

  if (showOnboarding) {
    return (
      <div className="fixed inset-0 z-[100] bg-[#020617] text-white flex flex-col p-6 overflow-y-auto custom-scrollbar">
        <div className="max-w-md mx-auto w-full py-8 space-y-10">
          <div className="text-center"><AppLogo className="w-16 h-16 mx-auto mb-4" /><h2 className="text-3xl font-black italic tracking-tighter uppercase text-emerald-500">Perfil Inicial</h2></div>
          <div className="space-y-8">
            <section className="space-y-4">
              <label className="block text-xs font-black uppercase text-slate-400">Gênero</label>
              <div className="grid grid-cols-2 gap-2">
                {['Homem', 'Mulher'].map(g => (
                  <button key={g} onClick={() => setOnboardingData({...onboardingData, gender: g})} className={`py-4 rounded-2xl text-xs font-black uppercase ${onboardingData.gender === g ? 'bg-emerald-600' : 'bg-white/5 text-slate-500'}`}>{g}</button>
                ))}
              </div>
            </section>
            <section className="space-y-4">
              <label className="block text-xs font-black uppercase text-slate-400">Informações da Moto</label>
              <div className="grid grid-cols-1 gap-4">
                <div className="bg-white/5 p-4 rounded-2xl">
                  <span className="text-[10px] font-black uppercase text-slate-500 block mb-1">Preço Gasolina (L)</span>
                  <input type="number" step="0.01" value={onboardingData.moto_fuel_price} onChange={e => setOnboardingData({...onboardingData, moto_fuel_price: parseFloat(e.target.value)})} className="bg-transparent text-white w-full text-xl font-black focus:outline-none" />
                </div>
                <div className="bg-white/5 p-4 rounded-2xl">
                  <span className="text-[10px] font-black uppercase text-slate-500 block mb-1">Quantos KM p/ litro?</span>
                  <input type="number" value={onboardingData.moto_km_per_liter} onChange={e => setOnboardingData({...onboardingData, moto_km_per_liter: parseInt(e.target.value)})} className="bg-transparent text-white w-full text-xl font-black focus:outline-none" />
                </div>
              </div>
            </section>
            <button onClick={handleOnboardingSubmit} className="w-full bg-emerald-600 py-6 rounded-2xl font-black uppercase text-sm shadow-2xl active-scale">FINALIZAR E ENTRAR</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen text-slate-100 overflow-hidden relative">
      <header className="px-6 py-4 bg-slate-900/60 backdrop-blur-xl border-b border-white/5 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3"><AppLogo className="w-8 h-8" /><div><h1 className="text-xs font-black uppercase italic tracking-tighter">MotoInvest</h1><p className="text-[9px] text-emerald-400 font-bold uppercase">{currentUser.name}</p></div></div>
        <button onClick={() => supabase.auth.signOut()} className="p-3 bg-white/5 border border-white/10 rounded-xl"><LogoutIcon className="w-4 h-4 text-slate-400" /></button>
      </header>

      <main className="flex-1 overflow-hidden relative z-10">
        {activeTab === 'chat' && (
          <div className="flex flex-col h-full">
            <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6 custom-scrollbar">
              {messages.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.role === Role.USER ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
                  <div className={`max-w-[90%] p-4 rounded-2xl shadow-xl ${msg.role === Role.USER ? 'bg-emerald-600 text-white rounded-br-none' : 'bg-slate-900/80 backdrop-blur-md border border-white/5 rounded-bl-none'}`}>
                    {msg.role === Role.MODEL && <div className="flex items-center gap-2 mb-2 pb-2 border-b border-white/5"><BotIcon className="w-3 h-3 text-emerald-400" /><span className="text-[9px] font-black uppercase text-emerald-400">Mentor IA</span></div>}
                    <MarkdownRenderer content={msg.text} />
                  </div>
                </div>
              ))}
              {isAILoading && <div className="flex items-center gap-2 text-emerald-500 font-black text-[9px] uppercase animate-pulse ml-4"><BotIcon className="w-3 h-3" /> Mentor calculando...</div>}
              <div ref={messagesEndRef} className="h-4" />
            </div>
            <div className="p-4 bg-slate-900/80 backdrop-blur-xl border-t border-white/5">
              <div className="flex items-center gap-2 max-w-2xl mx-auto">
                <input type="text" value={inputText} onChange={e => setInputText(e.target.value)} onKeyPress={e => e.key === 'Enter' && processAIPrompt(inputText)} placeholder="Conversar com o Mentor..." className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm focus:outline-none" />
                <button onClick={() => { processAIPrompt(inputText); setInputText(''); }} disabled={isAILoading || !inputText.trim()} className="bg-emerald-600 p-4 rounded-2xl active-scale"><SendIcon className="w-5 h-5 text-white" /></button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'ledger' && (
          <div className="h-full overflow-y-auto p-8 space-y-8 pb-24 custom-scrollbar animate-in fade-in">
            <h2 className="text-4xl font-black italic uppercase">Meu Corre</h2>
            <div className="space-y-6">
              <div className="bg-emerald-600/90 p-8 rounded-[40px] shadow-2xl border border-white/10 active-scale">
                 <label className="block text-[10px] font-black text-white/70 uppercase mb-2 tracking-widest">Ganhos de Hoje (Bruto)</label>
                 <div className="flex items-center gap-3">
                   <span className="text-2xl font-black text-white/50">R$</span>
                   <input type="number" placeholder="0,00" value={tempEarning} onChange={e => setTempEarning(e.target.value)} className="w-full bg-transparent text-5xl font-black text-white focus:outline-none placeholder:text-white/20" />
                 </div>
              </div>

              <div className="bg-rose-600/90 p-8 rounded-[40px] shadow-2xl border border-white/10 active-scale">
                 <label className="block text-[10px] font-black text-white/70 uppercase mb-2 tracking-widest">Gastos do Dia (Gasolina/Refeição)</label>
                 <div className="flex items-center gap-3">
                   <span className="text-2xl font-black text-white/50">R$</span>
                   <input type="number" placeholder="0,00" value={tempExpense} onChange={e => setTempExpense(e.target.value)} className="w-full bg-transparent text-5xl font-black text-white focus:outline-none placeholder:text-white/20" />
                 </div>
              </div>

              <button onClick={handleSaveDay} className="w-full bg-white text-slate-900 py-6 rounded-3xl font-black uppercase text-sm shadow-2xl active-scale flex items-center justify-center gap-3">
                <WalletIcon className="w-5 h-5" /> FECHAR DIA E CALCULAR LUCRO
              </button>
            </div>
          </div>
        )}

        {activeTab === 'calendar' && (
          <div className="h-full p-8 overflow-y-auto relative custom-scrollbar animate-in fade-in">
             <div className="flex justify-between items-center mb-6">
                <h2 className="text-4xl font-black italic uppercase">Agenda</h2>
                <div className="text-right flex items-center gap-2">
                    <button onClick={() => navigateMonth(-1)} className="p-1"><ChevronLeftIcon /></button>
                    <span className="text-[10px] font-black uppercase text-emerald-400">{MONTHS[viewDate.getMonth()]}</span>
                    <button onClick={() => navigateMonth(1)} className="p-1"><ChevronRightIcon /></button>
                </div>
             </div>
             
             <div className="bg-white/5 p-6 rounded-[40px] border border-white/5">
                <div className="grid grid-cols-7 gap-2 mb-4">{DAYS_OF_WEEK.map(d => <span key={d} className="text-[10px] font-black text-slate-600 text-center">{d}</span>)}</div>
                <div className="grid grid-cols-7 gap-2">
                   {Array.from({ length: calendarDays.firstDay }).map((_, i) => <div key={`empty-${i}`} />)}
                   {Array.from({ length: calendarDays.daysInMonth }).map((_, i) => {
                     const day = i + 1;
                     const status = getDayStatus(day);
                     return (
                       <button key={day} onClick={() => setSelectedDay(day)} className={`aspect-square flex flex-col items-center justify-center rounded-2xl border active-scale relative ${selectedDay === day ? 'border-emerald-500 bg-emerald-500/10' : 'border-white/5 bg-white/5'}`}>
                         <span className="text-xs font-black">{day}</span>
                         {status === 'due' && <div className="absolute bottom-1 w-1 h-1 rounded-full bg-rose-500 shadow-lg shadow-rose-500" />}
                         {status === 'paid' && <div className="absolute bottom-1 w-1 h-1 rounded-full bg-emerald-500 shadow-lg shadow-emerald-500" />}
                       </button>
                     );
                   })}
                </div>
             </div>

             {/* FIXED: Agenda Details Header with Sticky Close Button */}
             {selectedDay && (
               <div className="fixed inset-0 z-[100] bg-slate-950 flex flex-col animate-in slide-in-from-bottom duration-300">
                 <div className="sticky top-0 p-8 pb-4 flex justify-between items-center border-b border-white/5 bg-slate-950/80 backdrop-blur-xl z-20">
                    <div>
                      <h3 className="font-black uppercase italic text-emerald-500 text-2xl tracking-tighter">Dia {selectedDay}</h3>
                      <p className="text-[10px] font-black text-slate-500 uppercase">{MONTHS[viewDate.getMonth()]} {viewDate.getFullYear()}</p>
                    </div>
                    <button onClick={() => setSelectedDay(null)} className="px-6 py-3 bg-rose-600 rounded-2xl font-black text-[10px] uppercase shadow-xl active-scale">FECHAR</button>
                 </div>
                 <div className="flex-1 overflow-y-auto p-8 space-y-4 custom-scrollbar pb-10">
                   {bills.filter(b => b.dueDate === `${viewDate.getFullYear()}-${String(viewDate.getMonth() + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`).map(bill => (
                     <div key={bill.id} className="bg-slate-900 border border-white/5 p-6 rounded-[32px] flex justify-between items-center shadow-2xl">
                       <div><p className={`font-black uppercase text-base ${bill.isPaid ? 'line-through text-slate-600' : 'text-white'}`}>{bill.name}</p><p className="text-sm font-bold text-emerald-500 mt-1">R$ {bill.amount.toFixed(2)}</p></div>
                       <div className="flex items-center gap-3">
                         <button onClick={() => toggleBillPaid(bill.id, bill.isPaid)} className={`px-6 py-3 rounded-2xl text-[10px] font-black ${bill.isPaid ? 'bg-emerald-500/20 text-emerald-500' : 'bg-slate-800 text-slate-400'}`}>{bill.isPaid ? 'PAGO' : 'PAGAR'}</button>
                         <button onClick={() => deleteBill(bill.id)} className="p-3 text-rose-500 bg-rose-500/10 rounded-2xl"><TrashIcon className="w-5 h-5" /></button>
                       </div>
                     </div>
                   ))}
                   {bills.filter(b => b.dueDate === `${viewDate.getFullYear()}-${String(viewDate.getMonth() + 1).padStart(2, '0')}-${String(selectedDay).padStart(2, '0')}`).length === 0 && (
                     <div className="py-20 text-center opacity-30 italic text-sm">Nenhum boleto para este dia.</div>
                   )}
                 </div>
               </div>
             )}
          </div>
        )}

        {activeTab === 'stats' && (
          <div className="h-full overflow-y-auto p-8 space-y-8 pb-24 custom-scrollbar animate-in fade-in">
            <h2 className="text-4xl font-black italic uppercase">Metas</h2>
            
            <div className="bg-slate-900/60 border border-white/5 p-8 rounded-[40px] shadow-2xl">
               <div className="flex justify-between items-end mb-4">
                 <div>
                   <p className="text-[10px] font-black uppercase text-emerald-500 mb-1">Objetivo Atual</p>
                   <h3 className="text-xl font-black uppercase tracking-tighter italic">{userProfile?.goal_name || 'Minha Meta'}</h3>
                 </div>
                 <div className="text-right">
                   <p className="text-xl font-black text-emerald-500">{((totals.netProfit / (userProfile?.financial_goal || 1)) * 100).toFixed(1)}%</p>
                 </div>
               </div>
               <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden">
                 <div className="bg-emerald-500 h-full transition-all duration-1000" style={{ width: `${Math.min(100, (totals.netProfit / (userProfile?.financial_goal || 1)) * 100)}%` }} />
               </div>
               <p className="text-[10px] font-bold text-slate-500 mt-4 uppercase text-center">R$ {totals.netProfit.toFixed(2)} acumulados de R$ {userProfile?.financial_goal?.toFixed(2)}</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/5 p-6 rounded-[32px] text-center border border-white/5">
                <p className="text-[9px] font-black text-emerald-400 uppercase">Ganhos Diários</p>
                <p className="text-xl font-black">R$ {totals.totalEarned.toFixed(2)}</p>
              </div>
              <div className="bg-white/5 p-6 rounded-[32px] text-center border border-white/5">
                <p className="text-[9px] font-black text-rose-400 uppercase">Gastos/Custos</p>
                <p className="text-xl font-black text-rose-300">R$ {totals.totalSpent.toFixed(2)}</p>
              </div>
            </div>
            
            <div className="bg-emerald-600/10 border border-emerald-500/20 p-8 rounded-[40px] flex justify-around items-center">
                 <div className="text-center">
                   <p className="text-2xl font-black italic">R$ {(userProfile?.moto_fuel_price! / userProfile?.moto_km_per_liter!).toFixed(2)}</p>
                   <p className="text-[8px] font-black uppercase text-slate-500 tracking-widest">Gasto/KM</p>
                 </div>
                 <div className="w-[1px] h-10 bg-white/5" />
                 <div className="text-center">
                   <p className="text-2xl font-black italic">R$ {userProfile?.moto_km_per_liter}</p>
                   <p className="text-[8px] font-black uppercase text-slate-500 tracking-widest">KM/L</p>
                 </div>
            </div>
          </div>
        )}

        {activeTab === 'help' && (
          <div className="h-full overflow-y-auto p-8 space-y-8 pb-24 custom-scrollbar animate-in fade-in">
            <h2 className="text-4xl font-black italic uppercase text-white">Ajustes</h2>
            
            {/* Informações da Moto Editáveis */}
            <div className="bg-slate-900/40 border border-white/5 p-8 rounded-[40px] space-y-6">
               <h3 className="text-xs font-black uppercase text-emerald-500 tracking-[0.2em]">Telemetria da Moto</h3>
               <div className="space-y-4">
                 <div className="bg-white/5 p-4 rounded-2xl flex justify-between items-center">
                   <span className="text-[11px] font-black uppercase text-slate-400">Gasolina (R$/L)</span>
                   <input type="number" step="0.01" value={userProfile?.moto_fuel_price} onChange={e => updateMotoProfile({ moto_fuel_price: parseFloat(e.target.value) })} className="bg-transparent text-right font-black text-emerald-400 focus:outline-none w-20 text-lg" />
                 </div>
                 <div className="bg-white/5 p-4 rounded-2xl flex justify-between items-center">
                   <span className="text-[11px] font-black uppercase text-slate-400">Preço Óleo (R$)</span>
                   <input type="number" value={userProfile?.moto_oil_price} onChange={e => updateMotoProfile({ moto_oil_price: parseFloat(e.target.value) })} className="bg-transparent text-right font-black text-emerald-400 focus:outline-none w-20 text-lg" />
                 </div>
                 <div className="bg-white/5 p-4 rounded-2xl flex justify-between items-center">
                   <span className="text-[11px] font-black uppercase text-slate-400">Consumo (KM/L)</span>
                   <input type="number" value={userProfile?.moto_km_per_liter} onChange={e => updateMotoProfile({ moto_km_per_liter: parseInt(e.target.value) })} className="bg-transparent text-right font-black text-emerald-400 focus:outline-none w-20 text-lg" />
                 </div>
               </div>
            </div>

            {/* Metas Editáveis */}
            <div className="bg-slate-900/40 border border-white/5 p-8 rounded-[40px] space-y-6">
               <h3 className="text-xs font-black uppercase text-emerald-500 tracking-[0.2em]">Objetivo Financeiro</h3>
               <div className="space-y-4">
                 <input type="text" placeholder="Nome do seu sonho" value={userProfile?.goal_name} onChange={e => updateMotoProfile({ goal_name: e.target.value })} className="w-full bg-white/5 rounded-2xl p-4 text-xs font-black focus:outline-none text-white border border-white/5" />
                 <div className="bg-white/5 p-4 rounded-2xl flex justify-between items-center">
                   <span className="text-[11px] font-black uppercase text-slate-400">Valor Alvo (R$)</span>
                   <input type="number" value={userProfile?.financial_goal} onChange={e => updateMotoProfile({ financial_goal: parseFloat(e.target.value) })} className="bg-transparent text-right font-black text-emerald-500 focus:outline-none w-32 text-lg" />
                 </div>
               </div>
            </div>

            {/* Notificações */}
            <div className="bg-slate-900/40 border border-white/5 p-8 rounded-[40px] space-y-6">
              <div className="flex items-center gap-4">
                <div className={`p-4 rounded-2xl ${notifsEnabled ? 'bg-emerald-500/20 text-emerald-500' : 'bg-slate-800 text-slate-500'}`}><BellIcon className="w-6 h-6" /></div>
                <div className="flex-1">
                  <p className="text-xs font-black uppercase italic">Lembretes Automáticos</p>
                  <p className="text-[9px] font-bold text-slate-500 uppercase">{notifsEnabled ? 'Notificações Ativas' : 'Notificações Silenciadas'}</p>
                </div>
                {notifPermission === 'granted' ? (
                  <button onClick={toggleNotifs} className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase active-scale ${notifsEnabled ? 'bg-rose-600' : 'bg-emerald-600'}`}>
                    {notifsEnabled ? 'DESATIVAR' : 'ATIVAR'}
                  </button>
                ) : (
                  <button onClick={requestNotifPermission} className="bg-emerald-600 px-4 py-2 rounded-xl text-[9px] font-black uppercase">PERMITIR</button>
                )}
              </div>
            </div>
          </div>
        )}
      </main>

      <nav className="bg-slate-950/80 backdrop-blur-3xl border-t border-white/5 px-2 py-6 flex justify-around items-center sticky bottom-0 z-50">
        {[
          { id: 'chat', icon: BotIcon, label: 'Mentor' },
          { id: 'ledger', icon: WalletIcon, label: 'Corre' },
          { id: 'calendar', icon: CalendarIcon, label: 'Agenda' },
          { id: 'stats', icon: GraphIcon, label: 'Metas' },
          { id: 'help', icon: SupportIcon, label: 'Ajustes' },
        ].map((item) => (
          <button key={item.id} onClick={() => setActiveTab(item.id as any)} className={`flex flex-col items-center gap-2 transition-all px-4 ${activeTab === item.id ? 'text-emerald-400' : 'text-slate-600'}`}>
            <div className={`p-2 rounded-2xl transition-all active-scale ${activeTab === item.id ? 'bg-emerald-500/10 scale-110 shadow-lg' : ''}`}><item.icon className="w-6 h-6" /></div>
            <span className="text-[8px] font-black tracking-widest uppercase">{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default App;
